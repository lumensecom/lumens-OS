# Entrega LUMENS · Pasacables Arena · Demo

Producto ficticio e imágenes de demostración.

- Abre vista-previa.html desde la carpeta extraída.
- Sube las fotos de imagenes/ a la galería del producto en el mismo orden.
- Pega 1-producto.txt y 2-landing.txt en bloques de Liquid personalizado de un tema duplicado.
- En Shopify, configura 1 unidad en $49.900. En Releasit conserva el orden 1 → 2 → 3.
- Pack 1: $49.900 COP. Contribución estimada antes de pauta: $25.900 COP.
- Pack 2: $84.900 COP. Contribución estimada antes de pauta: $48.900 COP.
- Pack 3: $114.900 COP. Contribución estimada antes de pauta: $66.900 COP.
- En la vista privada de Shopify, prueba cada pack, cada variante, el CTA y que Releasit muestre el total correcto.
- Verifica fuentes, costos, stock, permisos y política de entrega antes de publicar.
