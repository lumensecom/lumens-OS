# Entrega LUMENS · Pasacables Arena · Demo

Plantilla: Simple explicativa · Ionfit.
Producto ficticio e imágenes de demostración.

- 1 unidad: $49.900 COP. Contribución estimada antes de pauta: $25.900 COP.
- 2 unidades: $84.900 COP. Contribución estimada antes de pauta: $48.900 COP.
- 3 unidades: $114.900 COP. Contribución estimada antes de pauta: $66.900 COP.

- Abre vista-previa.html desde la carpeta extraída.
- En un tema Horizon duplicado, oculta «Información del producto» y pega 1-producto.txt (27022 bytes) y 2-landing.txt (23669 bytes) en dos bloques de Liquid personalizado.
- Sube imagenes/ a la galería en el orden entregado y etiqueta cada foto con su color.
- Confirma disponibilidad de tallas y variantes. Asigna una foto a cada variante de color en Shopify y sube los demás medios a Contenido → Archivos.
- En Shopify confirma $49.900 para la unidad. En Releasit configura las cantidades 1 → 2 → 3 con los mismos totales y deja el envío prioritario sin marcar.
- En el celular, cambia cantidad y variante, abre Releasit y valida el total. Verifica que la barra fija aparezca después de pasar el botón principal.

## Lo que falta confirmar
- tabla de tallas
- plazo
- video
