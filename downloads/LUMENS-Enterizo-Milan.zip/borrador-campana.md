# Borrador · Enterizo Milán

Ángulo: Quieres verte arreglada para una salida sin tener que combinar varias prendas. → Un look de noche en una sola prenda

CTA: Elige tu pack y paga al recibir.
