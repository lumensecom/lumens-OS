# Entrega LUMENS · Enterizo Milán

Público: Colombian women looking for a one-piece outfit for dinner or a special occasion
Plantilla: Simple corta · Vestido Pádel.
Referencia: Foto frontal y captura de Dropkiller proporcionadas por Juan. Ficha identificada con ID 2309063. Las cifras, variantes y reseñas de referencia no se trataron como verificadas para LUMENS.

- 1 unidad: $149.900 COP.

- Abre vista-previa.html desde la carpeta extraída.
- En un tema Horizon duplicado, oculta «Información del producto» y pega 1-producto.txt (32445 bytes) y 2-landing.txt (22311 bytes) en dos bloques de Liquid personalizado.
- La galería de prueba es ilustrativa. Contrasta las imágenes con la prenda y reemplázalas por fotos aprobadas antes de usar el tema en una tienda.
- Confirma disponibilidad de tallas y variantes. Asigna una foto a cada variante de color en Shopify y sube los demás medios a Contenido → Archivos.
- En Shopify confirma $149.900 para la unidad. En Releasit configura las cantidades 1 con los mismos totales y deja el envío prioritario sin marcar.
- En el celular, cambia cantidad y variante, abre Releasit y valida el total. Verifica que la barra fija aparezca después de pasar el botón principal.

## Lo que falta confirmar
- fuente verificable
- costos completos
- tabla de tallas
- plazo
- video
- fotos aprobadas para publicar
